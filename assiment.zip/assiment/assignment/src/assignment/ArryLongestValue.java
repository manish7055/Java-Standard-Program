package assignment;

public class ArryLongestValue {
public static void main(String args[]) {
	int []arr= {12,56,54,32,70,34};
	int high=0;
	for(int i=0;i<arr.length;i++) {
		int temp=1;
		int count=1;
		for(int j=0;j<arr.length;j++) {
			if(arr[j]==(arr[i]+count)) {
				temp++;
				count++;
				j=0;
			}
		}
		if(high<temp) 
			high=temp;
		}
		System.out.println("logest value:"+high);
		
	}
	
}

