package assignment;

public class AvrageValueArray {
public static void main(String args[]) {
	int sum=0;
	int avrage=0;
	int arr[]= {3,4,6,8,7,5,9,10,1,2,};
	for(int i=0;i<arr.length;i++) {
		 sum=sum+arr[i];
		//System.out.println("Sum of these number"+sum);
		
	}
	avrage=sum/arr.length;
	System.out.println("Avrage of the value:"+avrage);
}
}
