package assignment;
import java.util.ArrayList;
import java.util.Arrays;

public class converArrayTOArrayLIst {
	public static void main(String args[]) {
    Integer[] array = {1, 2, 3, 4, 5};
    ArrayList<Integer> arrayList = new ArrayList<>(Arrays.asList(array));
    System.out.println("ArrayList: " + arrayList);

}

}
