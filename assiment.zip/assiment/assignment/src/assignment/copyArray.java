package assignment;

public class copyArray {
public static void main(String args[] ) {
	int arr[]= {2,4,6,5,7};
	int copyArray=0;
	for(int i=0;i<arr.length;i++) {
		copyArray=arr[i];
		System.out.println(copyArray);
	}
}
}
