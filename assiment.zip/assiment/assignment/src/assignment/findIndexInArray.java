package assignment;
import java.util.Scanner;
public class findIndexInArray {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int []arr= {1,2,6,5,9,4,2};
	int searchValue=5;
	int index=-1;
	for(int i=0;i<arr.length;i++) {
		if(arr[i]==searchValue) {
			index=i;
			break;
		}
	}
		if(index!=-1) {
		System.out.println("searchElement:"+index);	
		}else {
			System.out.println("Not found");
		
	}
}
}