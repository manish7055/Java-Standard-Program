package assignment;
import java.util.Scanner;
public class fourElementCombinationInArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = {1, 2, 3, 4, 5, 6, 13, 12, 16, 29, 30};
        System.out.print("My Array : ");
        for (int i = 0; i < arr.length; i++)
            System.out.print(arr[i] + " ");
        System.out.print("\nEnter A Number : ");
        int num = sc.nextInt();
        int flag = 0;
        for (int i = 0; i < arr.length - 3; i++) {
            for (int j = i + 1; j < arr.length - 2; j++) {
                for (int k = j + 1; k < arr.length - 1; k++) {
                    for (int l = k + 1; l < arr.length; l++) {
                        System.out.println("Combination Not Found!");
                    }
                }
                }
            }
        }
    }


