package assignment;

public class stringArrayShort {
public static void main(String args[]) {
	String tempstr="";
	int []num= {3,5,4,1,6,2};
	String []str= {"apple","bnana","orange","papya"};
	for(int i=0;i<num.length-1;i++) {
		for(int j=0;j<num.length-1-i;j++) {
		    int temp=0;
			if(num[j]>num[j+1]) {
				temp=num[j];
				num[j]=num[j+1];
				num[j+1]=temp;
			}
		}
	}
				System.out.println("Shorted Array");
				for(int i=0;i<num.length;i++) {
					System.out.print(num[i]+" ");
					
			
		
	}for(int i=0;i<str.length-1;i++) {
		for(int j=0;j<str.length-1-i;j++) {
		
		//SWAPING STRING
		tempstr=str[j];
		str[j]=str[j+1];
		str[j+1]=tempstr;
		}
	}
		System.out.println("Shorted String");
		for(int i=0;i<str.length;i++) {
			System.out.print(str[i]+" ");
		
	
}
}
}

	
