package assignment;

public class sumOfNumber {
public static void main(String args[] ) {
	int sum=0;
	int []arr= {1,2,5,6,4};
	for(int i=0;i<arr.length;i++) {
		
	sum+=arr[i];
	System.out.println(sum);
}
}
}